Imports System.Drawing
Imports System.Linq
Imports System.Windows.Forms
Imports CsvLibrarian.Theme

Namespace Forms

    ''' <summary>
    ''' Modal keyboard / feature reference. The content lives in <see cref="HelpContent.Text"/>
    ''' (a tiny markup, compiled in); this form just parses and renders it: bare text becomes a
    ''' blue section header, and each {action, description} becomes a two-column row.
    ''' </summary>
    Public Class HelpForm

        ' Row layout widths (the description wraps to DescW and grows in height).
        Private Const KeyW As Integer = 190
        Private Const GapW As Integer = 12
        Private Const DescW As Integer = 740

        Public Sub New()
            InitializeComponent()
            DarkTheme.StyleFlatButtons(btnClose)
            PopulateContent()
        End Sub

        Private Sub PopulateContent()
            pnlContent.SuspendLayout()
            For Each item In ParseHelp(HelpContent.Text)
                If item.IsHeader Then
                    Dim head = UiFactory.MakeLabel(item.Action, Palette.Accent, bold:=True, size:=9.0F)
                    head.Margin = New Padding(0, 10, 0, 2)
                    head.BackColor = Color.Transparent
                    pnlContent.Controls.Add(head)
                Else
                    pnlContent.Controls.Add(MakeRow(item.Action, item.Description))
                End If
            Next
            pnlContent.ResumeLayout()
        End Sub

        Private Function MakeRow(key As String, desc As String) As Control
            Dim d As New Label With {
                .Text = desc,
                .AutoSize = True,
                .MaximumSize = New Size(DescW, 0),
                .Location = New Point(KeyW + GapW, 2),
                .ForeColor = Color.FromArgb(170, 170, 174),
                .Font = New Font("Segoe UI", 9.0F)
            }
            Dim rowH = Math.Max(22, d.PreferredSize.Height)
            Dim k As New Label With {
                .Text = key,
                .AutoSize = False,
                .Size = New Size(KeyW, rowH),
                .Location = New Point(0, 2),
                .TextAlign = ContentAlignment.TopLeft,
                .ForeColor = Color.FromArgb(220, 220, 220),
                .Font = New Font("Segoe UI", 9.0F, FontStyle.Bold)
            }
            Dim row As New Panel With {
                .Size = New Size(KeyW + GapW + DescW, rowH + 6),
                .Margin = New Padding(0, 1, 0, 1)
            }
            row.Controls.Add(k)
            row.Controls.Add(d)
            Return row
        End Function

        ' ── Markup parser ─────────────────────────────────────────────────────────
        Private Structure HelpItem
            Public IsHeader As Boolean
            Public Action As String        ' header text, or the row's shortcut
            Public Description As String
        End Structure

        ''' <summary>Split the markup into headers (bare text) and {action, description} rows.</summary>
        Private Shared Iterator Function ParseHelp(src As String) As IEnumerable(Of HelpItem)
            Dim i As Integer = 0
            While i < src.Length
                Dim brace = src.IndexOf("{"c, i)
                If brace < 0 Then
                    Dim tail = src.Substring(i).Trim()
                    If tail.Length > 0 Then Yield New HelpItem With {.IsHeader = True, .Action = tail}
                    Exit While
                End If
                Dim header = src.Substring(i, brace - i).Trim()
                If header.Length > 0 Then Yield New HelpItem With {.IsHeader = True, .Action = header}

                Dim close = src.IndexOf("}"c, brace + 1)
                If close < 0 Then Exit While    ' malformed — stop gracefully
                Dim inner = src.Substring(brace + 1, close - brace - 1)
                Dim comma = inner.IndexOf(","c)
                Dim action = If(comma >= 0, inner.Substring(0, comma), inner).Trim()
                Dim desc = If(comma >= 0, inner.Substring(comma + 1), "").Trim()
                Yield New HelpItem With {.IsHeader = False, .Action = action, .Description = ExpandDescription(desc)}
                i = close + 1
            End While
        End Function

        ''' <summary>
        ''' Sentence-end ("." followed by a space) → line break; "~" → a blank line. Breaking
        ''' only on ". " keeps file tokens like ".EXPORT" / "collated.csv" on one line. Each
        ''' resulting line is trimmed and leading/trailing blank lines are removed.
        ''' </summary>
        Private Shared Function ExpandDescription(desc As String) As String
            Dim t = desc.Replace(". ", "." & vbCrLf).Replace("~", vbCrLf)
            Dim lines = t.Split({vbCrLf}, StringSplitOptions.None).Select(Function(x) x.Trim())
            Return String.Join(vbCrLf, lines).Trim()
        End Function

        Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
            Me.Close()
        End Sub

    End Class

End Namespace
