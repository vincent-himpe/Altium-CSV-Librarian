Namespace Global.CsvLibrarian

    ''' <summary>
    ''' The Help window content, in a tiny human-friendly markup that <c>HelpForm</c> parses.
    ''' This file is compiled into the program (it is NOT shipped as a separate data file),
    ''' so editing help is just editing this string.
    '''
    ''' FORMAT:
    '''   • Any text OUTSIDE curly braces is a SECTION HEADER (rendered in accent blue).
    '''   • Each <c>{action, description}</c> is a ROW: the part before the first comma is the
    '''     shortcut/action (bold), the rest is the description.
    '''   • In a description, a period followed by a space starts a new line (one sentence per
    '''     line) and a lone "~" inserts a blank line. Leading/trailing blank lines are trimmed.
    '''   • Do not use "{" or "}" inside a description; commas are fine (only the first splits).
    '''   • NOTE (VB): every line below must end with "&" — no blank lines inside the literal.
    ''' </summary>
    Friend Module HelpContent

        Public Const Text As String =
            "Navigation" &
            "{Up / Down, Move one row up or down}" &
            "{Left / Right  ·  Tab, Move between cells}" &
            "{Enter, Commit the edit and move down}" &
            "{Current row, The row holding the active cell is highlighted}" &
            "Editing" &
            "{Insert, Append a blank row with a fresh GUID}" &
            "{Ctrl + Insert, Append a row cloned from the last row}" &
            "{Ctrl + D, Copy Down (Safe). Fills the current cell from the one above only if it is empty, then moves down. In the Location column it instead increments the numeric suffix of the value above, so MARS177 becomes MARS178}" &
            "{Ctrl + Shift + D, Copy Down (Force). Copies the cell above verbatim (no increment) and moves down}" &
            "{Delete Row, Delete the current row after a confirmation. On the Edit menu and the toolbar. No hotkey}" &
            "{Ctrl + Q, Autosize all columns to fit their content}" &
            "{Ctrl + U, Unsort. Restore the original CSV row order}" &
            "{Ctrl + N, Normalize the fields of the active file}" &
            "{Manage Columns…, Add, rename, delete or reorder columns, and migrate data between columns}" &
            "Clipboard" &
            "{Ctrl + C, Copy the current cell to BOTH the internal clipboard and the Windows clipboard}" &
            "{Ctrl + Shift + C, Copy the current cell to the Windows clipboard only}" &
            "{Ctrl + V, Paste into the current column's selected cells. Uses the internal clipboard, or the Windows clipboard when the internal one is empty}" &
            "{Ctrl + Shift + V, Always paste from the Windows clipboard}" &
            "Find & Replace" &
            "{Ctrl + F, Find. Prompt for the search string}" &
            "{Ctrl + Shift + F, Find Cell. Use the current cell as the search string}" &
            "{F3, Find Next. Next cell containing the search string}" &
            "{Shift + F3, Find Next in Column. Next match in this column}" &
            "{Ctrl + R, Replace. Current cell becomes the clipboard value}" &
            "{Ctrl + Shift + R, Replace Next. Next match becomes the clipboard value}" &
            "{Ctrl + Alt + R, Replace in Column. Next match in this column}" &
            "Advanced Clipboard" &
            "{Alt + Down / Alt + Up, Increment or decrement the clipboard index (0-9, rolls over)}" &
            "{Ctrl + 0…9, Copy the current cell into clipboard column 0-9 at the current index row}" &
            "{Alt + 0…9, Paste clipboard column 0-9 into the current cell}" &
            "{(numeric keypad), The digit shortcuts also work on the numeric keypad}" &
            "{Advanced Clipboard…, Edit the 10x10 clipboard grid (Settings menu)}" &
            "Tools" &
            "{Location Analysis, Scans the Location column across all open files. Reports numbering gaps, duplicate locations with their files, and any entries containing a hyphen. Cells with several comma-separated locations are split for analysis. Offers a Print button for the missing list}" &
            "{Integrity Check, Checks for duplicate GUIDs across all open files. The toolbar icon turns green when the index is clean and red when duplicates are found}" &
            "{Location Report, Print Description, Manufacturer Part Number 1 and Location for the chosen files}" &
            "{Collated BOM, Merge the open files into collated.csv, de-duplicated by part number plus description}" &
            "{Convert ID, Convert an ID column into a GUID Index column}" &
            "Web Lookup" &
            "{Right-click a part number, Search the configured sites for a Manufacturer Part Number 1 cell}" &
            "{Ctrl + W, Quick Web Lookup. Search all QuickLook sites for the current row's part number}" &
            "{WebCrawler…, Configure the search engines (Settings menu)}" &
            "Files & Folders" &
            "{Ctrl + O, Open a working folder}" &
            "{F5, Reload the working folder}" &
            "{Ctrl + L, Open the working folder in Explorer}" &
            "{Ctrl + Shift + L, Create a new library in the working folder}" &
            "{Ctrl + S, Save the active file. A backup is written first}" &
            "{Ctrl + Shift + S, Save all modified files}" &
            "{Recently Used, Reopen one of the last five folders (File menu)}" &
            "{Create Archive, Zip all CSVs in the working folder. On the File menu and the toolbar}" &
            "{Alt + F4, Exit. Prompts to save or discard unsaved changes}" &
            "Import / Export" &
            "{Ctrl + E, Export Row. Write the current row to a .EXPORT JSON file}" &
            "{Import Records…, Browse and import .EXPORT files (Tools menu)}" &
            "Backups" &
            "{Backups dropdown, Pick Current for the live editable file, or a timestamp to preview that backup read-only. A preview shows a light, inverted, non-editable grid. Selecting a backup while the file is unsaved offers Save and Proceed}" &
            "{Restore, Pull the previewed backup into the working file as an unsaved change. Only Restore changes the file}" &
            "Settings & Notes" &
            "{Normalizer Rules…, Edit the normalizer.json rule sets}" &
            "{API Integration…, Store supplier API credentials}" &
            "{Options…, Autosave interval and toggle, auto-normalize on save, and archive on exit}" &
            "{Show Config Files, Open the settings and config folder}" &
            "{GUID / Index column, The first column. Auto-generated and read-only, shown in a muted grey in every view}" &
            "{Auto-save, Saves modified files a short time after typing stops. Toggle in Options}"

    End Module

End Namespace
