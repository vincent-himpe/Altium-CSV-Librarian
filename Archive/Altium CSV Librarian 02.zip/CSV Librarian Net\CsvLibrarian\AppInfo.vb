Namespace Global.CsvLibrarian

    ''' <summary>Application-wide constants.</summary>
    Public Module AppInfo

        ''' <summary>
        ''' Application version. Appended to the main window caption at startup,
        ''' e.g. "Altium CSV Librarian V 0.1".
        ''' </summary>
        Public Const Version As String = "-Beta- 0.2"

        ''' <summary>
        ''' Comma-separated header row written to a brand-new library CSV
        ''' (File ▸ New Library). Edit this list to change the default schema.
        ''' </summary>
        Public Const NewLibraryHeaders As String =
            "Index,Library Ref,Library Path,Footprint Ref,Footprint Path,Description," &
            "Manufacturer 1,Manufacturer Part Number 1,Location,LCSC,Digikey,Mouser,TME"

        ''' <summary>Body text shown in the About window.</summary>
        Public Const AboutString As String =
            "Designed by Vincent Himpe." & vbCrLf &
            "Coded by Claude" & vbCrLf & vbCrLf &
            "Released under Creative Commons 0 License" & vbCrLf &
            "No implied warranties. User assumes all risk."

        ''' <summary>
        ''' App-local single-cell clipboard used by Edit ▸ Copy / Paste. This is
        ''' deliberately NOT the Windows clipboard. Empty at startup.
        ''' </summary>
        Public OurClipboard As String = ""

        ''' <summary>
        ''' The current search string (set by Find / Find Cell / Find in Column) and
        ''' the "replace with" value used by the Replace-Next commands. Empty at startup.
        ''' </summary>
        Public FindString As String = ""

    End Module

End Namespace
