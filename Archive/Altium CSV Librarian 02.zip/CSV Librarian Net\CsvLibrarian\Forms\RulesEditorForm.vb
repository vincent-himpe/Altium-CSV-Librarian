Imports System.Drawing
Imports System.Text.Json
Imports System.Windows.Forms
Imports CsvLibrarian.Models
Imports CsvLibrarian.Services
Imports CsvLibrarian.Theme

Namespace Forms

    ''' <summary>
    ''' Visual editor for the folder's normalizer.json. Left: the list of rule
    ''' sets (each targets files by name/glob). Right: for the current file, every
    ''' column (except Index) is listed with an editable Transforms cell, plus an
    ''' optional "build a column" rule. A column whose Transforms cell is blank is
    ''' left untouched. Standard Windows chrome; only the label text colours are kept.
    ''' Edits are made on a working copy; the caller persists <see cref="ResultConfig"/>.
    ''' </summary>
    Public Class RulesEditorForm

        Private _config As NormalizerConfig
        Private ReadOnly _activeFile As String
        Private ReadOnly _columns As List(Of String)
        Private _selectedIndex As Integer = -1
        Private _suppress As Boolean = False

        Public ReadOnly Property ResultConfig As NormalizerConfig
            Get
                Return _config
            End Get
        End Property

        ''' <summary>Parameterless constructor for the Windows Forms designer.</summary>
        Public Sub New()
            _config = New NormalizerConfig()
            _activeFile = Nothing
            _columns = New List(Of String)()
            InitializeComponent()
            ApplyLabelColors()
        End Sub

        Public Sub New(config As NormalizerConfig, activeFile As String, columns As List(Of String))
            _config = CloneConfig(config)
            _activeFile = activeFile
            _columns = If(columns, New List(Of String)())
            InitializeComponent()
            ApplyLabelColors()
            RefreshRuleList(SelectMatching())
        End Sub

        Private Shared Function CloneConfig(cfg As NormalizerConfig) As NormalizerConfig
            If cfg Is Nothing Then Return New NormalizerConfig()
            Dim json = JsonSerializer.Serialize(cfg)
            Return JsonSerializer.Deserialize(Of NormalizerConfig)(json)
        End Function

        Private Function SelectMatching() As Integer
            If String.IsNullOrEmpty(_activeFile) Then Return If(_config.RuleSets.Count > 0, 0, -1)
            Dim rs = NormalizerService.FindRuleSet(_config, _activeFile)
            If rs Is Nothing Then Return If(_config.RuleSets.Count > 0, 0, -1)
            Return _config.RuleSets.IndexOf(rs)
        End Function

        ''' <summary>
        ''' Standard Windows colour scheme everywhere, except the label text colours,
        ''' which are kept as before. The divider gets a visible standard colour.
        ''' </summary>
        Private Sub ApplyLabelColors()
            rsHeading.ForeColor = Palette.Accent
            matchLbl.ForeColor = Palette.TextMuted
            nzLbl.ForeColor = Palette.TextMuted
            nzHint.ForeColor = Palette.TextDim
            tgtLbl.ForeColor = Palette.TextMuted
            srcLbl.ForeColor = Palette.TextMuted
            sepLbl.ForeColor = Palette.TextMuted
            srcHint.ForeColor = Palette.TextDim
            buildLine.BackColor = SystemColors.ControlDark

            ' Header row: medium grey background, bold black text.
            nzGrid.EnableHeadersVisualStyles = False
            nzGrid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(190, 190, 190)
            nzGrid.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            nzGrid.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.FromArgb(190, 190, 190)
            nzGrid.ColumnHeadersDefaultCellStyle.Font = New Font(nzGrid.Font, FontStyle.Bold)
        End Sub

        ' ── Rule set list ────────────────────────────────────────────────────────

        ''' <summary>How a rule set's match pattern is shown in the list:
        ''' upper-case with any ".csv" extension removed (as in the main window).</summary>
        Private Shared Function DisplayMatch(match As String) As String
            If String.IsNullOrEmpty(match) Then Return "(unnamed)"
            Dim m = match
            If m.EndsWith(".csv", StringComparison.OrdinalIgnoreCase) Then
                m = m.Substring(0, m.Length - 4)
            End If
            Return m.ToUpperInvariant()
        End Function

        Private Sub RefreshRuleList(selectIndex As Integer)
            _suppress = True
            ruleList.BeginUpdate()
            ruleList.Items.Clear()
            For Each rs In _config.RuleSets
                ruleList.Items.Add("  " & DisplayMatch(rs.Match))
            Next
            ruleList.EndUpdate()
            _suppress = False

            If _config.RuleSets.Count = 0 Then
                _selectedIndex = -1
                LoadEditor(Nothing)
            Else
                Dim idx = Math.Max(0, Math.Min(selectIndex, _config.RuleSets.Count - 1))
                ruleList.SelectedIndex = idx      ' triggers OnRuleSelected
            End If
            delRuleBtn.Enabled = _config.RuleSets.Count > 0
        End Sub

        Private Sub OnRuleSelected(sender As Object, e As EventArgs) Handles ruleList.SelectedIndexChanged
            If _suppress Then Return
            ' Commit edits of the previously selected rule set before switching.
            nzGrid.EndEdit()
            CommitNormalizationsToModel()
            _selectedIndex = ruleList.SelectedIndex
            If _selectedIndex >= 0 AndAlso _selectedIndex < _config.RuleSets.Count Then
                LoadEditor(_config.RuleSets(_selectedIndex))
            End If
        End Sub

        Private Sub AddRuleSet() Handles addRuleBtn.Click
            Dim rs As New NormalizerRuleSet With {.Match = If(String.IsNullOrEmpty(_activeFile), "newfile.csv", _activeFile)}
            _config.RuleSets.Add(rs)
            RefreshRuleList(_config.RuleSets.Count - 1)
        End Sub

        Private Sub DeleteRuleSet() Handles delRuleBtn.Click
            If _selectedIndex < 0 OrElse _selectedIndex >= _config.RuleSets.Count Then Return
            _config.RuleSets.RemoveAt(_selectedIndex)
            RefreshRuleList(_selectedIndex - 1)
        End Sub

        ' ── Editor <-> model ───────────────────────────────────────────────────────

        Private Sub LoadEditor(rs As NormalizerRuleSet)
            _suppress = True
            Dim enabled = rs IsNot Nothing
            matchBox.Enabled = enabled
            nzGrid.Enabled = enabled
            buildEnable.Enabled = enabled

            nzGrid.Rows.Clear()
            If rs Is Nothing Then
                matchBox.Text = ""
                buildEnable.Checked = False
                SetBuildEnabled(False)
                _suppress = False
                Return
            End If

            matchBox.Text = rs.Match

            ' One row per current-file column (except the Index/GUID column). The
            ' Transforms cell is pre-filled from the rule set if it has an entry.
            For Each col In _columns
                If String.Equals(col, "Index", StringComparison.OrdinalIgnoreCase) Then Continue For
                Dim tf As String = ""
                Dim existing = rs.Normalizations.FirstOrDefault(
                    Function(n) String.Equals(n.Column, col, StringComparison.OrdinalIgnoreCase))
                If existing IsNot Nothing Then tf = String.Join("|", existing.Transforms)
                nzGrid.Rows.Add(col, tf)
            Next

            Dim hasBuild = rs.Build IsNot Nothing
            buildEnable.Checked = hasBuild
            If hasBuild Then
                targetBox.Text = rs.Build.Target
                sourcesBox.Text = String.Join("|", rs.Build.Sources)
                sepBox.Text = rs.Build.Separator
                skipEmptyChk.Checked = rs.Build.SkipEmpty
            Else
                targetBox.Text = ""
                sourcesBox.Text = ""
                sepBox.Text = "-"
                skipEmptyChk.Checked = True
            End If
            SetBuildEnabled(hasBuild)
            _suppress = False
        End Sub

        Private Sub SetBuildEnabled(enabledState As Boolean)
            targetBox.Enabled = enabledState
            sourcesBox.Enabled = enabledState
            sepBox.Enabled = enabledState
            skipEmptyChk.Enabled = enabledState
        End Sub

        Private Function CurrentRuleSet() As NormalizerRuleSet
            If _selectedIndex < 0 OrElse _selectedIndex >= _config.RuleSets.Count Then Return Nothing
            Return _config.RuleSets(_selectedIndex)
        End Function

        Private Sub CommitMatchToModel() Handles matchBox.TextChanged
            If _suppress Then Return
            Dim rs = CurrentRuleSet()
            If rs Is Nothing Then Return
            rs.Match = matchBox.Text.Trim()
            _suppress = True
            If _selectedIndex >= 0 AndAlso _selectedIndex < ruleList.Items.Count Then
                ruleList.Items(_selectedIndex) = "  " & DisplayMatch(rs.Match)
            End If
            _suppress = False
        End Sub

        ''' <summary>Rebuild the rule set's normalizations from the grid. Columns
        ''' whose Transforms cell is blank contribute nothing.</summary>
        Private Sub CommitNormalizationsToModel()
            Dim rs = CurrentRuleSet()
            If rs Is Nothing Then Return
            Dim list As New List(Of ColumnNormalization)()
            For Each row As DataGridViewRow In nzGrid.Rows
                If row.IsNewRow Then Continue For
                Dim col = Convert.ToString(row.Cells(0).Value)
                If String.IsNullOrWhiteSpace(col) Then Continue For
                Dim tfRaw = Convert.ToString(row.Cells(1).Value)
                If String.IsNullOrWhiteSpace(tfRaw) Then Continue For   ' blank -> no transform
                Dim transforms As New List(Of String)()
                For Each part In tfRaw.Split("|"c)
                    If part.Trim().Length > 0 Then transforms.Add(part.Trim())
                Next
                If transforms.Count = 0 Then Continue For
                list.Add(New ColumnNormalization With {.Column = col.Trim(), .Transforms = transforms})
            Next
            rs.Normalizations = list
        End Sub

        Private Sub OnBuildEnabledChanged(sender As Object, e As EventArgs) Handles buildEnable.CheckedChanged
            SetBuildEnabled(buildEnable.Checked)
            CommitBuildToModel()
        End Sub

        Private Sub CommitBuildToModel() Handles targetBox.TextChanged, sourcesBox.TextChanged,
                                               sepBox.TextChanged, skipEmptyChk.CheckedChanged
            If _suppress Then Return
            Dim rs = CurrentRuleSet()
            If rs Is Nothing Then Return
            If Not buildEnable.Checked Then
                rs.Build = Nothing
                Return
            End If
            Dim sources As New List(Of String)()
            For Each part In sourcesBox.Text.Split("|"c)
                If part.Trim().Length > 0 Then sources.Add(part.Trim())
            Next
            rs.Build = New BuildRule With {
                .Target = targetBox.Text.Trim(),
                .Sources = sources,
                .Separator = If(sepBox.Text.Length = 0, "-", sepBox.Text),
                .SkipEmpty = skipEmptyChk.Checked
            }
        End Sub

        Private Sub OnOk(sender As Object, e As EventArgs) Handles okBtn.Click
            ' Flush any in-progress grid edit, then commit all editors to the model.
            nzGrid.EndEdit()
            CommitMatchToModel()
            CommitNormalizationsToModel()
            CommitBuildToModel()
            Me.DialogResult = DialogResult.OK
            Me.Close()
        End Sub

    End Class

End Namespace
