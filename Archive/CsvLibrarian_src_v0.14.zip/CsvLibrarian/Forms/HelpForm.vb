Imports System.Drawing
Imports System.Windows.Forms
Imports CsvLibrarian.Theme

Namespace Forms

    ''' <summary>Modal keyboard / feature reference.</summary>
    Public Class HelpForm

        Private Shared ReadOnly Sections As (Title As String, Items As (Key As String, Desc As String)())() = {
            ("Navigation", New (String, String)() {
                ("↑ / ↓", "Move one row up / down"),
                ("← / →  ·  Tab", "Move between cells"),
                ("Enter", "Commit and move down"),
                ("Current row", "The active cell's row is highlighted")
            }),
            ("Editing", New (String, String)() {
                ("Insert", "Append a blank row with a new GUID"),
                ("Ctrl + Insert", "Append a row cloned from the last row"),
                ("Ctrl + D", "Copy Down (Safe) — fill current cell from above only if it is empty; then move down"),
                ("Ctrl + Shift + D", "Copy Down (Force) — copy the cell above (overwrite), then move down"),
                ("Ctrl + C", "Copy the current cell to the app clipboard"),
                ("Ctrl + V", "Paste into the current column's selected cell(s) — app clipboard, or Windows clipboard if empty"),
                ("Delete Row", "Delete the current row (Edit menu)"),
                ("Ctrl + Q", "Autosize all columns to fit content"),
                ("Ctrl + U", "Unsort — restore the original CSV row order"),
                ("Ctrl + N", "Normalize Fields on the active file"),
                ("Manage Columns…", "Add / rename / delete / reorder columns; Migrate data between columns")
            }),
            ("Find & Replace", New (String, String)() {
                ("Ctrl + F", "Find — prompt for the search string"),
                ("Ctrl + Shift + F", "Find Cell — use the current cell as search string"),
                ("F3", "Find Next — next cell containing the search string"),
                ("Shift + F3", "Find Next in Column — next match in this column"),
                ("Ctrl + R", "Replace — current cell ← clipboard (remembers old text)"),
                ("Ctrl + Shift + R", "Replace Next — next match ← clipboard"),
                ("Ctrl + Alt + R", "Replace in Column — next match in this column")
            }),
            ("Advanced Clipboard", New (String, String)() {
                ("Alt + ↓ / Alt + ↑", "Increment / decrement the clipboard index (0–9, rolls over)"),
                ("Ctrl + 0…9", "Copy the current cell into clipboard column 0–9 (at the current index row)"),
                ("Alt + 0…9", "Paste clipboard column 0–9 into the current cell"),
                ("(numeric keypad)", "The digit shortcuts also work on the numeric keypad"),
                ("Advanced Clipboard…", "Edit the 10×10 clipboard grid (Settings)")
            }),
            ("Web Lookup", New (String, String)() {
                ("Right-click part no.", "Search the configured sites for a ""Manufacturer Part Number 1"" cell"),
                ("Ctrl + W", "Quick Web Lookup — search all QuickLook sites for the current row's part number"),
                ("WebCrawler…", "Configure the search engines (Settings)")
            }),
            ("Files & Folders", New (String, String)() {
                ("Ctrl + O", "Open a working folder"),
                ("F5", "Reload the working folder"),
                ("Ctrl + L", "Open the working folder in Explorer"),
                ("Ctrl + Shift + L", "Create a new library in the working folder"),
                ("Ctrl + S", "Save the active file (backup written first)"),
                ("Ctrl + Shift + S", "Save all modified files"),
                ("Recently Used", "Reopen one of the last 5 folders (File menu)"),
                ("Create Archive", "Zip all CSVs in the working folder (File menu)"),
                ("Alt + F4", "Exit — prompts to save or discard unsaved changes")
            }),
            ("Import / Export", New (String, String)() {
                ("Ctrl + E", "Export Row — write the current row to a .EXPORT JSON file"),
                ("Import Records…", "Browse and import .EXPORT files (Tools)"),
                ("Convert ID", "Convert an ""ID"" column into a GUID ""Index"" column (Tools)")
            }),
            ("Settings & Notes", New (String, String)() {
                ("Normalizer Rules…", "Edit normalizer.json rule sets"),
                ("API Integration…", "Store supplier API credentials"),
                ("Options…", "Autosave interval / on-off, auto-normalize on save, archive on exit"),
                ("Show Config Files", "Open the settings / config folder"),
                ("GUID / Index column", "First column — auto-generated, read-only"),
                ("Backups", "Last 5 versions kept in .backups/ (toolbar Backups dropdown + Restore)"),
                ("Auto-save", "Saves modified files ~30 s after typing stops (toggle in Options)")
            })
        }

        Public Sub New()
            InitializeComponent()
            DarkTheme.StyleFlatButtons(btnClose)
            PopulateContent()
        End Sub

        Private Sub PopulateContent()
            For Each section In Sections
                ' Section headers keep their accent colour; everything else is
                ' standard (black keys, dark-grey descriptions).
                Dim head = UiFactory.MakeLabel(section.Title.ToUpperInvariant(), Palette.Accent, bold:=True, size:=8.0F)
                head.Margin = New Padding(0, 10, 0, 2)
                head.BackColor = Color.Transparent
                pnlContent.Controls.Add(head)
                For Each item In section.Items
                    pnlContent.Controls.Add(MakeRow(item.Key, item.Desc))
                Next
            Next
        End Sub

        Private Function MakeRow(key As String, desc As String) As Control
            Dim row As New Panel With {.Size = New Size(452, 26), .Margin = New Padding(0, 1, 0, 1)}
            Dim k As New Label With {
                .Text = key,
                .Size = New Size(150, 22),
                .Location = New Point(0, 2),
                .TextAlign = ContentAlignment.MiddleLeft,
                .ForeColor = Color.FromArgb(220, 220, 220),
                .Font = New Font("Segoe UI", 9.0F, FontStyle.Bold)
            }
            Dim d As New Label With {
                .Text = desc,
                .AutoSize = False,
                .Size = New Size(290, 22),
                .Location = New Point(158, 2),
                .TextAlign = ContentAlignment.MiddleLeft,
                .ForeColor = Color.FromArgb(170, 170, 174),
                .Font = New Font("Segoe UI", 9.0F)
            }
            row.Controls.Add(k)
            row.Controls.Add(d)
            Return row
        End Function

        Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
            Me.Close()
        End Sub

    End Class

End Namespace
