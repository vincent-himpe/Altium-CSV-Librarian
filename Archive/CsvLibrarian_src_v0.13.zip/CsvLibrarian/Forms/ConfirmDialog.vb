Imports System.Drawing
Imports System.Windows.Forms
Imports CsvLibrarian.Theme

Namespace Forms

    ''' <summary>
    ''' A small dark-themed yes/no dialog with caller-defined button captions. Use
    ''' <see cref="Ask"/> for any simple true/false decision instead of the light
    ''' Windows <c>MessageBox</c>. Returns True when the OK (affirmative) button is
    ''' clicked, False for Cancel / Esc / closing the window.
    ''' </summary>
    Public Class ConfirmDialog
        Inherits Form

        Private ReadOnly _message As New Label()
        Private ReadOnly _okButton As New Button()
        Private ReadOnly _cancelButton As New Button()

        Private Sub New(title As String, message As String, okText As String, cancelText As String)
            Font = New Font("Segoe UI", 9.0F)
            Text = title
            FormBorderStyle = FormBorderStyle.FixedDialog
            StartPosition = FormStartPosition.CenterParent
            MinimizeBox = False
            MaximizeBox = False
            ShowInTaskbar = False
            BackColor = DarkTheme.FormBackground
            ForeColor = DarkTheme.TextNormal
            ClientSize = New Size(460, 168)

            _message.AutoSize = False
            _message.SetBounds(18, 18, 424, 88)
            _message.ForeColor = DarkTheme.TextNormal
            _message.TextAlign = ContentAlignment.TopLeft
            _message.Text = message
            Controls.Add(_message)

            _okButton.Text = okText
            _okButton.DialogResult = DialogResult.OK
            _cancelButton.Text = cancelText
            _cancelButton.DialogResult = DialogResult.Cancel
            DarkTheme.StyleFlatButtons(_okButton, _cancelButton)

            ' Size each button to its caption ("Save and Proceed" is wide) and lay them
            ' out bottom-right: [Cancel] [OK].
            Const margin As Integer = 16, gap As Integer = 8, btnH As Integer = 30
            Dim okW = Math.Max(96, TextRenderer.MeasureText(okText, _okButton.Font).Width + 28)
            Dim cancelW = Math.Max(96, TextRenderer.MeasureText(cancelText, _cancelButton.Font).Width + 28)
            Dim btnY = ClientSize.Height - btnH - margin
            _okButton.SetBounds(ClientSize.Width - margin - okW, btnY, okW, btnH)
            _cancelButton.SetBounds(_okButton.Left - gap - cancelW, btnY, cancelW, btnH)
            Controls.Add(_okButton)
            Controls.Add(_cancelButton)

            AcceptButton = _okButton
            CancelButton = _cancelButton
        End Sub

        ''' <summary>
        ''' Show the dialog modally and return True only if the affirmative button was
        ''' clicked. <paramref name="okText"/> is the affirmative caption (e.g. "Save and
        ''' Proceed"); <paramref name="cancelText"/> is the negative caption.
        ''' </summary>
        Public Shared Function Ask(owner As IWin32Window, title As String, message As String,
                                   Optional okText As String = "OK",
                                   Optional cancelText As String = "Cancel") As Boolean
            Using dlg As New ConfirmDialog(title, message, okText, cancelText)
                Return dlg.ShowDialog(owner) = DialogResult.OK
            End Using
        End Function

    End Class

End Namespace
