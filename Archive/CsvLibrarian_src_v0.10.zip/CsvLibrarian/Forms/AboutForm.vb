Imports System.Drawing
Imports System.Windows.Forms

Namespace Forms

    ''' <summary>Dark-themed "About" dialog.</summary>
    Public Class AboutForm

        Public Sub New()
            InitializeComponent()
            lblAppTitle.Text = "Altium CSV Librarian V " & AppInfo.Version
            lblAbout.Text = AppInfo.AboutString

            ' Flat dark OK button (visual-styled buttons ignore BackColor).
            btnOk.FlatStyle = FlatStyle.Flat
            btnOk.FlatAppearance.BorderColor = Color.FromArgb(85, 85, 90)
            btnOk.BackColor = Color.FromArgb(63, 63, 70)
            btnOk.ForeColor = Color.FromArgb(220, 220, 220)
            btnOk.UseVisualStyleBackColor = False
        End Sub

    End Class

End Namespace
